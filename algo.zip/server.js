/**
 * WaleszDesk — Bybit API Backend
 * Node.js server do składania zleceń na Bybit
 *
 * Uruchomienie:
 *   npm install express cors crypto node-fetch
 *   node server.js
 *
 * Serwer działa na http://localhost:3001
 */

const express = require('express');
const cors = require('cors');
const crypto = require('crypto');

const app = express();
app.use(express.json());
app.use(cors({ origin: '*' }));

const PORT = 3001;

// ─── KONFIGURACJA ────────────────────────────────────────────────
// Wpisz swoje klucze tutaj LUB ustaw zmienne środowiskowe:
// BYBIT_API_KEY=xxx BYBIT_API_SECRET=xxx node server.js
const CONFIG = {
  apiKey:    process.env.BYBIT_API_KEY    || 'WPISZ_SWOJ_API_KEY',
  apiSecret: process.env.BYBIT_API_SECRET || 'WPISZ_SWOJ_API_SECRET',
  testnet:   process.env.BYBIT_TESTNET === 'true' || false,
};

const BASE_URL = CONFIG.testnet
  ? 'https://api-testnet.bybit.com'
  : 'https://api.bybit.com';

// ─── POMOCNICZE ──────────────────────────────────────────────────
function sign(params, timestamp, recvWindow) {
  const payload = timestamp + CONFIG.apiKey + recvWindow + params;
  return crypto
    .createHmac('sha256', CONFIG.apiSecret)
    .update(payload)
    .digest('hex');
}

async function bybitRequest(method, endpoint, body = {}) {
  const timestamp   = Date.now().toString();
  const recvWindow  = '5000';
  const bodyStr     = method === 'POST' ? JSON.stringify(body) : '';
  const queryStr    = method === 'GET'  ? new URLSearchParams(body).toString() : '';
  const signInput   = method === 'POST' ? bodyStr : queryStr;
  const signature   = sign(signInput, timestamp, recvWindow);

  const url = BASE_URL + endpoint + (queryStr ? '?' + queryStr : '');

  const res = await fetch(url, {
    method,
    headers: {
      'Content-Type':   'application/json',
      'X-BAPI-API-KEY':      CONFIG.apiKey,
      'X-BAPI-SIGN':         signature,
      'X-BAPI-TIMESTAMP':    timestamp,
      'X-BAPI-RECV-WINDOW':  recvWindow,
      'X-BAPI-SIGN-TYPE':    '2',
    },
    body: method === 'POST' ? bodyStr : undefined,
  });

  return res.json();
}

// ─── ROUTES ──────────────────────────────────────────────────────

// Sprawdź status serwera
app.get('/status', (req, res) => {
  res.json({
    ok: true,
    testnet: CONFIG.testnet,
    hasKeys: CONFIG.apiKey !== 'WPISZ_SWOJ_API_KEY',
    server: 'WaleszDesk Backend v1.0',
  });
});

// Pobierz saldo konta
app.get('/balance', async (req, res) => {
  try {
    const data = await bybitRequest('GET', '/v5/account/wallet-balance', {
      accountType: 'UNIFIED',
    });
    if (data.retCode !== 0) {
      return res.status(400).json({ ok: false, error: data.retMsg });
    }
    const coins = data.result?.list?.[0]?.coin || [];
    const usdt  = coins.find(c => c.coin === 'USDT');
    res.json({
      ok:      true,
      balance: parseFloat(usdt?.walletBalance  || 0).toFixed(2),
      equity:  parseFloat(usdt?.equity         || 0).toFixed(2),
      avail:   parseFloat(usdt?.availableToWithdraw || 0).toFixed(2),
    });
  } catch (err) {
    res.status(500).json({ ok: false, error: err.message });
  }
});

// Pobierz otwarte pozycje
app.get('/positions', async (req, res) => {
  try {
    const data = await bybitRequest('GET', '/v5/position/list', {
      category: 'linear',
      settleCoin: 'USDT',
    });
    if (data.retCode !== 0) {
      return res.status(400).json({ ok: false, error: data.retMsg });
    }
    const positions = (data.result?.list || [])
      .filter(p => parseFloat(p.size) > 0)
      .map(p => ({
        symbol:     p.symbol,
        side:       p.side,
        size:       p.size,
        entryPrice: p.avgPrice,
        liqPrice:   p.liqPrice,
        unrealisedPnl: parseFloat(p.unrealisedPnl).toFixed(2),
        leverage:   p.leverage,
      }));
    res.json({ ok: true, positions });
  } catch (err) {
    res.status(500).json({ ok: false, error: err.message });
  }
});

// Złóż zlecenie
app.post('/order', async (req, res) => {
  try {
    const {
      symbol,
      side,       // 'Buy' lub 'Sell'
      orderType,  // 'Limit' lub 'Market'
      qty,        // ilość kontraktów
      price,      // cena entry (tylko dla Limit)
      stopLoss,
      takeProfit,
      leverage,
    } = req.body;

    // Walidacja
    if (!symbol || !side || !orderType || !qty) {
      return res.status(400).json({ ok: false, error: 'Brakujące parametry: symbol, side, orderType, qty' });
    }

    // Ustaw dźwignię
    if (leverage) {
      await bybitRequest('POST', '/v5/position/set-leverage', {
        category:     'linear',
        symbol,
        buyLeverage:  String(leverage),
        sellLeverage: String(leverage),
      });
    }

    // Złóż zlecenie
    const orderBody = {
      category:    'linear',
      symbol,
      side,
      orderType,
      qty:         String(qty),
      timeInForce: orderType === 'Market' ? 'IOC' : 'GTC',
    };

    if (orderType === 'Limit' && price) {
      orderBody.price = String(price);
    }
    if (stopLoss) {
      orderBody.stopLoss      = String(stopLoss);
      orderBody.slTriggerBy   = 'LastPrice';
    }
    if (takeProfit) {
      orderBody.takeProfit    = String(takeProfit);
      orderBody.tpTriggerBy   = 'LastPrice';
    }

    const data = await bybitRequest('POST', '/v5/order/create', orderBody);

    if (data.retCode !== 0) {
      return res.status(400).json({ ok: false, error: data.retMsg, raw: data });
    }

    res.json({
      ok:      true,
      orderId: data.result?.orderId,
      message: `Zlecenie ${side} ${qty} ${symbol} złożone pomyślnie`,
    });

  } catch (err) {
    res.status(500).json({ ok: false, error: err.message });
  }
});

// Pobierz historię zleceń
app.get('/orders', async (req, res) => {
  try {
    const data = await bybitRequest('GET', '/v5/order/history', {
      category: 'linear',
      limit:    '20',
    });
    if (data.retCode !== 0) {
      return res.status(400).json({ ok: false, error: data.retMsg });
    }
    res.json({ ok: true, orders: data.result?.list || [] });
  } catch (err) {
    res.status(500).json({ ok: false, error: err.message });
  }
});

// ─── START ───────────────────────────────────────────────────────
app.listen(PORT, () => {
  console.log('');
  console.log('╔══════════════════════════════════════╗');
  console.log('║      WaleszDesk Backend v1.0         ║');
  console.log('╠══════════════════════════════════════╣');
  console.log(`║  Adres:   http://localhost:${PORT}       ║`);
  console.log(`║  Testnet: ${CONFIG.testnet ? 'TAK ⚠️              ' : 'NIE (live trading) '}  ║`);
  console.log(`║  Klucze:  ${CONFIG.apiKey !== 'WPISZ_SWOJ_API_KEY' ? 'skonfigurowane ✓     ' : 'BRAK — ustaw klucze!  '}║`);
  console.log('╚══════════════════════════════════════╝');
  console.log('');
  if (CONFIG.apiKey === 'WPISZ_SWOJ_API_KEY') {
    console.log('⚠️  UWAGA: Brak kluczy API!');
    console.log('   Uruchom z kluczami:');
    console.log('   BYBIT_API_KEY=xxx BYBIT_API_SECRET=xxx node server.js');
    console.log('');
  }
});
